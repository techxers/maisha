<?php

namespace Facade\FlareClient\Enums;

/** @deprecated  */
class GroupingTypes
{
    const TOP_FRAME = 'topFrame';

    const EXCEPTION = 'exceptionClass';
}
