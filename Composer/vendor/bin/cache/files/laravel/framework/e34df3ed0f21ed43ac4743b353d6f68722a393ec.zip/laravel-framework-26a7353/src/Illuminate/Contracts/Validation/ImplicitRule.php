<?php

namespace Illuminate\Contracts\Validation;

interface ImplicitRule extends Rule
{
    //
}
